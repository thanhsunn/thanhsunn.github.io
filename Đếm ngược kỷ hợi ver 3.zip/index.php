﻿<!DOCTYPE html>
<html>
<head>
<title>Chúc Mừng Năm Mới 2019</title>
<link rel="icon" href="https://hou.edu.vn/files/anhhoso/Vietnam.jpg" type="image/x-icon">
</head>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/clock.css">
<body>
<!--// Ghé thăm Blog.Omfg.Vn
  _    _                         _   _             __     __             
 | |  | |                       | \ | |            \ \   / /             
 | |__| | __ _ _ __  _ __  _   _|  \| | _____      _\ \_/ /__  __ _ _ __ 
 |  __  |/ _` | '_ \| '_ \| | | | . ` |/ _ \ \ /\ / /\   / _ \/ _` | '__|
 | |  | | (_| | |_) | |_) | |_| | |\  |  __/\ V  V /  | |  __/ (_| | |   
 |_|  |_|\__,_| .__/| .__/ \__, |_| \_|\___| \_/\_/   |_|\___|\__,_|_|   
              | |   | |     __/ |                                        
              |_|   |_|    |___/                                         

NguyenDangNhat Happy New Year//-->			  
<div id="scg-nyc-wrapper">
    <div id="scg-nyc-msg" style="font-family: monospace;">Chúc Mừng Năm Mới 2019</div>
    <div class="scg-nyc-digits-wrapper">
        <div class="scg-nyc-digits-type">Days</div>
        <div class="scg-nyc-digit" id="scg-clock-days" style="color:#444444;">
            <span>0</span><span>0</span><span>0</span>
        </div>
    </div>
    <div class="scg-nyc-digits-wrapper scg-nyc-sep"> : </div>
    <div class="scg-nyc-digits-wrapper">
        <div class="scg-nyc-digits-type">Hours</div>
        <div class="scg-nyc-digit" id="scg-clock-hr" style="color:#444444;">
            <span>0</span><span>0</span>
        </div>
    </div>
    <div class="scg-nyc-digits-wrapper scg-nyc-sep"> : </div>
    <div class="scg-nyc-digits-wrapper">
        <div class="scg-nyc-digits-type">Minutes</div>
        <div class="scg-nyc-digit" id="scg-clock-mins" style="color:#444444;">
            <span>0</span><span>0</span>
        </div>
    </div>
    <div class="scg-nyc-digits-wrapper scg-nyc-sep"> : </div>
    <div class="scg-nyc-digits-wrapper">
        <div class="scg-nyc-digits-type">Seconds</div>
        <div class="scg-nyc-digit" id="scg-clock-secs" style="color:#444444;">
            <span>0</span><span>0</span>
        </div>
    </div>
</div>
<script src="js/main.js" type="text/JavaScript"></script>
<script  src="js/fw.js" type="text/javascript"></script>
 <!-- banner Blog.Omfg.VN -->
 <div style="position:fixed;z-index:9999;bottom:-50px;left:0;width:100%;height:104px;background:url(https://3.bp.blogspot.com/-uQrQaR3IkxE/WF9dDUUVLLI/AAAAAAAAAdw/VKNA5q7FJSQX5OWofOiPafEEENaoBcY9wCLcB/s1600/nentet.png) repeat-x bottom left;"></div><img style="position:fixed;z-index:9999;bottom:20px;left:20px" src="http://3.bp.blogspot.com/-4Zt-ZB4tols/UsA_qIR0w9I/AAAAAAAAA3w/Ffyy-5OqGec/s320/banner_header.png"/>
<!-- banner Blog.Omfg.VN -->
<iframe allow='accelerometer;autoplay;encrypted-media;gyroscope;picture-in-picture' allowfullscreen='' frameborder='' height='1' src=' https://www.youtube.com/embed/LPHJCZFVJFg?autoplay=1&playlist=GfJCAZIbx5A&loop=1&cc_load_policy=1&rel=0&controls=1&showinfo=0' style='position:absolute;display:block;float:left;width:auto;bottom:999999999px' width='1'>
</iframe>
</body>
</html>
